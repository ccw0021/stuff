#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtMath>
#include <QtDebug>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ////
    AB=5;
    AC=4;
    AD=6.4;
    BC=5.2;
    BD=6;
    CD=4.3;
    ////
    //Node Loop //// This can be optimized some angles not needed
        //get values from sql
            ///getRSSI();
            ///RSSItoLength();
        //Solve triangles ////cos^-1((a^2+b^2-c^2)/2ab) = C
            //Solve triangle 1
                ////AB = c,AC = b,CB =a
                t1_a = getAngle(AC,AB,BC);
                t1_b = getAngle(AB,BC,AC); //CHECKED FOR ACC
                t1_c = getAngle(BC,AC,AB);
                    qDebug()<<"A1"<< t1_a<<"B1"<< t1_b<<"C1"<< t1_c<<endl;
            //Solve triangle 2
                ////BD = c, CD = b,BC = a
                t2_a = getAngle(CD,BD,BC);
                t2_b = getAngle(BD,BC,CD); //CHECKED FOR ACC
                t2_c = getAngle(BC,CD,BD);
                    qDebug()<<"A2"<< t2_a<<"B2"<< t2_b<<"C2"<< t2_c<<endl;
        //Get node cords
        //// DUE TO 2D NATURE OF AB, CD COULD BE ABOVE AB. Below AB is always assumed if CD is above map will be upside down but still functional!
            Ax=0;
            Ay=0;

            Bx=AB;
            By=0;

            Cx=getX(t1_a,AC) + 0; // can be either + or - (Depends on if ang A is acute(+) or obtuse(-))
            Cy=getY(t1_a,AC) + 0; //will be + but + is down

            Dx=getX(t2_b,BD) + AB;// can be either + or - (- if ang B is acute and Dx > AB)
            Dy=getY(t2_b,BD) + 0; // will be + but + is down
    //Draw nodes
        //set up scene
            myScene = new QGraphicsScene(this);
             myScene->setItemIndexMethod(QGraphicsScene::NoIndex); //speeds up??
             myScene->setSceneRect(-200,-150,400,300);
             myScene->setBackgroundBrush(Qt::white);

             ui->graphicsView->setScene(myScene);
             ui->graphicsView->setRenderHint(QPainter::Antialiasing);
        //connect points
             int Scale = 10;
             int pointScale = 4;
            myScene->addLine(Ax*Scale,Ay*Scale,Bx*Scale,By*Scale,QPen(Qt::gray));
            myScene->addLine(Ax*Scale,Ay*Scale,Cx*Scale,Cy*Scale,QPen(Qt::gray));
            myScene->addLine(Bx*Scale,By*Scale,Dx*Scale,Dy*Scale,QPen(Qt::gray));
            myScene->addLine(Cx*Scale,Cy*Scale,Dx*Scale,Dy*Scale,QPen(Qt::gray));
        //draw points
            myScene->addEllipse(Ax*Scale-.5*pointScale,Ay*Scale-.5*pointScale,pointScale,pointScale,QPen(Qt::red),QBrush(Qt::red));       //a    RED
            myScene->addEllipse(Bx*Scale-.5*pointScale,By*Scale-.5*pointScale,pointScale,pointScale,QPen(Qt::yellow),QBrush(Qt::yellow)); //b    YELLOW
            myScene->addEllipse(Cx*Scale-.5*pointScale,Cy*Scale-.5*pointScale,pointScale,pointScale,QPen(Qt::blue),QBrush(Qt::blue));     //c    BLUE
            myScene->addEllipse(Dx*Scale-.5*pointScale,Dy*Scale-.5*pointScale,pointScale,pointScale,QPen(Qt::green),QBrush(Qt::green));   //d    GREEN
        //draw length
            QGraphicsTextItem *textAB = new QGraphicsTextItem(QString::number(AB));
                textAB->setPos(Ax*Scale + Scale,Ay*Scale-Scale);
            QGraphicsTextItem *textAC = new QGraphicsTextItem(QString::number(AC));
                textAC->setPos(Ax*Scale-Scale,Ay*Scale+Scale);
            QGraphicsTextItem *textBD = new QGraphicsTextItem(QString::number(BD));
                textBD->setPos(Bx*Scale+Scale,Ay*Scale+Scale);
            QGraphicsTextItem *textCD = new QGraphicsTextItem(QString::number(CD));
                textCD->setPos(Cx*Scale+Scale,Cy*Scale+Scale);

            myScene->addItem(textAB);
            myScene->addItem(textAC);
            myScene->addItem(textBD);
            myScene->addItem(textCD);
    //Object Loop
}

void MainWindow::getRSSI() //TODO
{}
void MainWindow::RSSItoLength() //TODO
{}
qreal MainWindow::getAngle(qreal a,qreal b,qreal c)
{
    return qAcos((a*a+b*b-c*c)/(2*a*b));
}
qreal MainWindow::getX(qreal ang,qreal hypot) //uses absolute angle from AB
{
    qreal alpha;
    if(ang > M_PI_2)
        {alpha = ang - M_PI_2 +M_PI;} //makes x negative
    else
        {alpha = M_PI_2 - ang;} // x is positive

    return (qSin(alpha)*hypot);

}
qreal MainWindow::getY(qreal ang,qreal hypot) //uses absolute angle from AB
{
    qreal alpha;
    if(ang > M_PI_2)
        {alpha = ang - M_PI_2;} //y is always negative
    else
        {alpha = M_PI_2 - ang;} // y is always negative

    return (qCos(alpha)*hypot);
}

void MainWindow::drawNodes() //currently not needed
{}

MainWindow::~MainWindow()
{
    delete ui;
}
