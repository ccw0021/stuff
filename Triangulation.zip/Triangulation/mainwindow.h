#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsItem>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // include rssi's later
    qreal AB=11,AC=10,AD=13,BC=14,BD=13,CD=7; //Length
    qreal t1_a,t1_b,t1_c; //triangle1 angles  //ANGLES ARE IN RADIANS
    qreal t2_a,t2_b,t2_c; //triangle2 angles
    qreal Ax,Ay,Bx,By,Cx,Cy,Dx,Dy; //Position

    qreal getAngle(qreal a,qreal b,qreal c);
    qreal getX(qreal ang,qreal hypot);
    qreal getY(qreal ang,qreal hypot);
    void getRSSI();
    void RSSItoLength();

    void drawNodes();

    QGraphicsScene* myScene;

private:
    Ui::MainWindow *ui;


};

#endif // MAINWINDOW_H
